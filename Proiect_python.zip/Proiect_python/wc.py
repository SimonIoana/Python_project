
def wc(filename):
    try:
        fin = open(filename, 'r')
        text = fin.read()
        fin.close()
    except IOError:
        print ("File %s not found" % filename)
        raise SystemExit
    number_of_characters = len(text)
    number_of_lines = text.count('\n') + 1
    wordlist = text.split(None)
    number_of_words = len(wordlist)
    print ("%d %d %d %s" % (number_of_lines, number_of_words, number_of_characters, filename))

if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        for filename in sys.argv[1:]:
            wc(filename)
    else:
        print ("usage wc textfile")